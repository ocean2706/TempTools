SyslogNet
=========

.Net Syslog client. Supports both RFC 3164 and RFC 5424 Syslog standards as well as UDP and encrypted TCP transports.

Installation
============

Available on NuGet:
```
Install-Package SyslogNet.Client
```
